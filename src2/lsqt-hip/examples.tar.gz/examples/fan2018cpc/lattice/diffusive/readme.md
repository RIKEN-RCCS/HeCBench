This directory contains example 1 (figure 1) presented in the paper:

Z. Fan, V. Vierimaa, and Ari Harju, 
GPUQT: An efficient linear-scaling quantum transport code 
fully implemented on graphics processing units, 
Comput. Phys. Commun. 230, 113 (2018). 
https://doi.org/10.1016/j.cpc.2018.04.013

Both the inputs and outputs are here.
